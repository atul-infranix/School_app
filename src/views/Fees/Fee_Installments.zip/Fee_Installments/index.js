import React from 'react'
import FeeProfile from './feeProfile'
import FeeProfileTable from './feeProfileTable'
import useMediaQuery from '@mui/material/useMediaQuery';
const Fee_Installments = () => {
    const matches = useMediaQuery('(max-width:1023px)');
    return (
        <div>
            <p style={{ fontSize: !matches ? '20px' : "18px", paddingLeft: !matches ? "" : "7px", fontWeight: 'bold', position: !matches ? 'fixed' : "", left: !matches ? "50%" : "", top: !matches ? "18px" : "", zIndex: !matches ? "20" : "", marginTop: !matches ? "" : "-8px" }}>
                FEE INSTALLMENTS
            </p>
            <div className='grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 px-2  ' style={{ border: '1px dashed #e5e7eb' }}>
                <div className='pl-1 lg:col-span-2 xl:col-span-2 col-span-2 lg:pr-5 ' style={!matches ? { borderRight: '1px dashed  #e5e7eb' } : {}} >
                    <FeeProfile />
                </div>
                <div className='pt-3 xl:col-span-3 lg:col-span-2 col-span-2 lg:pl-5 ' style={!matches ? { borderLeft: '1px dashed  #e5e7eb' } : {}}>
                    <div>
                        <FeeProfileTable />
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Fee_Installments

